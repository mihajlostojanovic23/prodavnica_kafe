-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3308
-- Generation Time: Feb 06, 2021 at 04:05 PM
-- Server version: 8.0.18
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `prodavnica_kafe`
--

-- --------------------------------------------------------

--
-- Table structure for table `korisnik`
--

DROP TABLE IF EXISTS `korisnik`;
CREATE TABLE IF NOT EXISTS `korisnik` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ime` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `prezime` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `broj_tel` int(40) NOT NULL,
  `grad` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `adresa` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `lozinka` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `korisnik`
--

INSERT INTO `korisnik` (`id`, `ime`, `prezime`, `broj_tel`, `grad`, `adresa`, `email`, `lozinka`) VALUES
(2, 'Mihajlo', 'Stojanovic', 612908749, 'Malosiste', 'MalosisteBB', 'mihajlomixi@live.co.uk', 'proba123'),
(3, 'Mihajlo', 'Stojanovic', 121321423, 'Nis', 'NIs', 'mihajlo@gmail.com', 'proba123'),
(6, 'Nikola', 'Nikolic', 121321423, 'Nis', 'NIs', 'nikola@gmail.com', 'proba123'),
(7, 'Nikola', 'Nikolic', 121321423, 'Nis', 'NIs', 'nikolab@gmail.com', 'proba123'),
(8, 'Mihajlo', 'Stojanovic', 121321423, 'Nis', 'NIs', 'mihajlobre@hotmail.rs', 'proba123');

-- --------------------------------------------------------

--
-- Table structure for table `proizvodi`
--

DROP TABLE IF EXISTS `proizvodi`;
CREATE TABLE IF NOT EXISTS `proizvodi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ime` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `opis` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `slika` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `cena` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `proizvodi`
--

INSERT INTO `proizvodi` (`id`, `ime`, `opis`, `slika`, `cena`) VALUES
(51, 'Mochaccino', 'Priprema se od cf espresso baze, tople čokolade, mleka i mlečne pene. Ne možete da se odlučite između kapućina sa savršenom penom i tople čokolade? Probajte ih zajedno!', 'coffe8.jpg', 160),
(53, 'Baby Marakesh', 'Priprema se na bazi cf espresso kafe zajedno sa nutelom, mlekom, mlečnom penom i kakaom u maloj šolji. Pregršt bogatih i neodoljivih ukusa.', 'coffe10.jpg', 180),
(54, 'Doppio Marakesh', 'Zrna kafe iz tropskih krajeva zamepana u cf espresso blendu čine bazu za ovaj kremasti napitak od kafe zajedno sa nutelom, mlekom, mlečnom penom i kakaom služimo piće, idealno za jutarnju dozu kofeina, ili za dezert posle ručka.', 'coffe11.jpg', 170),
(55, 'Latte Macchiato', 'Cf espresso sa bogatom dozom mleka i mlečne pene. Najpopularniji kremasti napitak od kafe. Italijanskog porekla. Predstavlja dugi napitak, idealan za doručak.', 'coffe12.jpg', 180),
(56, 'Latte Macchiato \'\'Cioccolato\'\'', 'Cf espresso sa bogatom dozom mleka i mlečne pene, dekorisan kakao sirupom. Latte Macchiato baza sa dodatkom čokolade i dekoracija specijalnim kakao sirupom čine - Latte Macchiato \'\'Cioccolato\'\'!', 'coffe13.jpg', 185),
(57, 'Latte Macchiato \'\'Caramello\'\'', 'Cf espresso sa bogatom dozom mleka i mlečne pene, dekorisan karamel sirupom. Priprema se od Latte Macchiato baze, a dekorisan je karamel sirupom', 'coffe14.jpg', 190),
(58, 'Cafe Mocha', 'Naš espresso blend zajedno sa šlagom i sirupom od čokolade. Ovaj napitak predstavlja kombinaciju ukusa i boja, sačinjen od slojeva čokolade, mleka, espresso kafe i šlaga. Savršeno piće za udobnu atmosferu u društvu dobrih prijatelja...', 'coffe15.jpg', 190),
(59, 'Cafe Mocha Bianca', 'Verzija cafe mocha sa belom čokoladom, mlekom, espresso kafom i šlagom, dekorisan cimetom ili kakaom. Prefinjeno i delikatno piće...', 'coffe16.jpg', 180),
(60, 'Cortado ', 'Espresso u maloj čaši, ukoji se sipa mleko u odnosu 1:2. Napitak popularan u španiji i portugaliji, u australiji poznat kao piccolo (mali cafe latte), a na Kubi kao Cortadito.', 'coffe17.png', 190),
(61, 'Plasmaccino', 'Toping po želji, plazma keks, mleko, slatka pavlaka, jedna doza espresso kafe i šlag na vrhu. Osveženje i energija u jednoj čaši.', 'coffe18.png', 180),
(62, 'Tiramisu Iced Coffee', 'Dve kugle sladoleda, tiramisu sirup, kakao, 1 doza kafe i mleveni plazma keks kao dekoracija. Uživaćete u harmoniji ukusa!', 'coffe19.jpg', 190),
(63, 'Vanilla Berry Ice Coffee', 'Dve kugle sladoleda od vanile, hladno mleko, 2 doze kafe, led, sirup po želji, šlag na vrhu... I uživanje može da počne!', 'coffe20.jpg', 200),
(64, 'Ice Latte Deluxe', 'Još jedna verzija pića sa slojevima različitih boja. Predstavlja hladan napitak od kafe i priprema se od cf espresso baze zajedno sa mlekom, šećerom i sirupom od vanile. Isprobajte osvežavajući... Deluxe napitak!', 'coffe21.jpg', 210),
(65, 'Mambo Coffee', 'Nema razloga da vam dan prođe bez kafe samo zato što je napolju toplo! Naš mambo coffee je ledena kafa koja se priprema od espresso baze sa sirupom od kokosa, a dekorisan je čokoladnim topingom i kokosom. Napitak koji je blag, ali dovoljan za prijatan dan', 'coffe22.jpg', 220),
(66, 'Frozeccino', 'Za obožavaoce kafe u potrazi za osveženjem! Ova ledena kafa će vas podići, kombinujući vrhunski ukus cf kafe sa ledom i slatkom pavlakom u hlladnom, kremastom i osvežavajućem napitku!', 'coffe23.jpg', 210),
(67, 'Frozeccino Cioccolatto', 'Napravite prijatnu pauzu od vaših dnevnih obaveza! Uživajte u napitku koji se priprema od jedne doze cf espresso kafe, pavlake, leda i čokoladnog sirupa!', 'coffe24.jpg', 220),
(68, 'Frozeccino Caramello', 'Kada želite latte macchiato caramel, ali želite da bude hladan, gust i sočan - Želite frozeccino caramello. Pomešamo cf espresso sa ledom, dodamo malo slatke pavlake i karamel toping da bismo dobili kombinaciju koja predstavlja najbolje iz svih sastojaka1', 'coffe25.jpg', 220),
(69, 'Galliano\'s Hot-Flower', 'Klasični c%f espresso zajedno sa likerom galliano, medom i sltakom pavlakom, ekskluzivno c%f piće... Sveže i elegantno sa delikatnim ukusom vanile...', 'coffe26.jpg', 210),
(70, 'Espresso Corretto', 'Tradicionalni italijanski večernji napitak sa alkoholom. cf espresso u kombinaciji sa pićem po vašoj želji: Sambuca, Brandy, Bailey\'s...', 'coffe27.jpg', 200),
(71, 'Tia Caffe', 'Klasični internacionalni napitak napravljen od cf espresso kafe, žutog šećera, likera i šlaga. Ovo je večernje piće koje u sećanje priziva mirise i ukuse tropskih biljki kao što su vanila i kafa.', 'coffe29.jpg', 210),
(72, 'Bacardi Caramel Macchiato', 'CF espresso u kombinaciji sa mlekom, mlečnom penom, kubanskim rumom i karamelom čini bacardi caramel macchiato. Ova verzija kombinuje ukuse karamele i ruma što čini jedinstvenu harmoniju sa ukusom kafe.', 'coffe30.jpg', 210),
(73, 'Irish Coffee', 'Tradicionalna irska kafa: c%f espresso, viski ballantines, slatka pavlaka... Uživajte u harmoniji ukusa!', 'coffe31.jpg', 220),
(78, 'Sorendo', 'Specijalni c%f recept: c%f espresso, disaranno amaretto, advocaat, eierliquer. Probajte nešto novo, različito i... posebno!', 'coffe32.jpg', 210),
(79, 'Cafe Mocha Bianca', 'Priprema se na bazi cf espresso kafe zajedno sa nutelom, mlekom, mlečnom penom i kakaom u maloj šolji. Pregršt bogatih i neodoljivih ukusa.', 'coffe9.jpg', 190);

-- --------------------------------------------------------

--
-- Table structure for table `utisak`
--

DROP TABLE IF EXISTS `utisak`;
CREATE TABLE IF NOT EXISTS `utisak` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ime` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `utisak` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `utisak`
--

INSERT INTO `utisak` (`id`, `ime`, `email`, `utisak`) VALUES
(11, 'Nikola', 'nikola@gmail.com', 'Savršeno je!'),
(13, 'Marko', 'marko@gmail.com', 'Najbolji ste! Svaka čast!');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
